const express = require('express');
const https = require('https');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 443; // HTTPS default port

// Load SSL certificate and private key from the keys folder
const sslOptions = {
    key: fs.readFileSync(path.join(__dirname, 'keys', 'privatekey.pem')),
    cert: fs.readFileSync(path.join(__dirname, 'keys', 'certificate.pem'))
};

// Sample route for testing
app.get('/', (req, res) => {
    res.send('Hello, this is a secure HTTPS Express API!');
});

// Create an HTTPS server
https.createServer(sslOptions, app).listen(port, () => {
    console.log(`Server is running on https://localhost:${port}`);
});